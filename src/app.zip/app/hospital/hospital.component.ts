import { Component, OnInit } from '@angular/core';
import { DrService } from '../dr.service';
import { Dr } from '../models/dr';

@Component({
  selector: 'app-hospital',
  templateUrl: './hospital.component.html',
  styleUrls: ['./hospital.component.css']
})
export class HospitalComponent{

}
