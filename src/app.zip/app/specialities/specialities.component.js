// const count = document.querySelector(".count"),
//   title = document.querySelector(".count-title");

// count.innerText = 1;

// setInterval(() => {
//   if (count.innerText < 1000) {
//     count.innerText++;
//   } else {
//     title.innerText = "followers on instagram.";
//     title.style.color = "#000";
//   }
// }, 5);
