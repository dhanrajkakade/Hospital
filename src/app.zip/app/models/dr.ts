export interface Dr {
    did:number,
    first_Name:string,
    last_Name:string,
    email:string,
    password:string,
    specialist:string,
    gender:number,
    age:number,
    phone:number,
    dr_Status:string,
}