export interface Pat {
    pid:number,
    full_name:string,
    age:number,
    gender:number,
    address:string,
    phone:number,
    email:string,
    symptoms:string
}